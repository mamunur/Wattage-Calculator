<?php
function wattage_calculator_plugin_admin_menu() {
    add_menu_page(
        'Wattage Calculator',
        'Wattage Calculator',
        'manage_options',
        'wattage-calculator',
        '', // Callback, leave empty
        'dashicons-calendar',
        5 // Position
    );
	add_submenu_page( 'wattage-calculator', 'Category & Models', 'Category & Models', 'manage_options', 'edit-tags.php?taxonomy=category_models');
}

add_action( 'admin_menu', 'wattage_calculator_plugin_admin_menu' );
add_action( 'parent_file', 'menu_highlight' );
function menu_highlight( $parent_file ) {
        global $current_screen;

        $taxonomy = $current_screen->taxonomy;
        if ( $taxonomy == 'category_models' ) {
            $parent_file = 'wattage-calculator';
        }

        return $parent_file;
    }
function wattage_calculator_custom_post_type() {
    // preparing parameters
    $params = array(
      'labels' => array(
          'name' => __('Generstors'),
          'singular_name' => __('Generstor'),
    	  'all_items'			=> __('All Generstors', 'welldone'),
    	  'search_items'		=> __('Search Generstors', 'welldone'),
    	  'not_found'          	=> __('No Generstors found', 'welldone'),
    	  'not_found_in_trash' 	=> __('No Generstors found in Trash',  'welldone'),
    	  'menu_name'			=> __('Generstors', 'welldone')
        ),
          'public'              => true,
    	  'show_ui'            	=> true, 
    	  'show_in_menu' 	    => 'wattage-calculator',
          'has_archive'         => false,
		  'capability_type'    	=> 'page',
		  'publicly_queryable'  => true,
		  'rewrite'             => array( 'slug'=>'generstors','with_front'=> true,'page' => true,
    'feeds'=> true  ),
    	  'exclude_from_search' => false,
    	  'supports'			=> array('title', 'discussion', 'thumbnail', )
    );

    // registering the post type
    register_post_type('generstors', $params);
    $appliances = array(
      'labels' => array(
          'name' => __('Appliances'),
          'singular_name' => __('Appliances'),
    	  'all_items'			=> __('All Appliances', 'welldone'),
    	  'search_items'		=> __('Search Appliances', 'welldone'),
    	  'not_found'          	=> __('No Appliances found', 'welldone'),
    	  'not_found_in_trash' 	=> __('No Appliances found in Trash',  'welldone'),
    	  'menu_name'			=> __('Appliances', 'welldone')
        ),
          'public'              => true,
    	  'show_ui'            	=> true, 
    	  'show_in_menu' 	    => 'wattage-calculator',
          'has_archive' => true,
		  'capability_type'    	=> 'page',
    	  'exclude_from_search' => false,
    	  'supports'			=> array('title', 'discussion', 'thumbnail', )
    );

    // registering the post type
    register_post_type('appliances', $appliances);
    /** MAKE AND MODELS * */
    // Add new taxonomy, make it hierarchical (like categories)
    $labels = array(
        'name' => _x('Category & Models', 'taxonomy general name', 'textdomain'),
        'singular_name' => _x('Category & Models', 'taxonomy singular name', 'textdomain')
    );

    // preaparing arguments
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'publicly_queryable' 	=> true,
    	'show_ui'            	=> true, 
        'query_var' => true,
        'rewrite' => array('slug' => 'category_models'),
    );

    register_taxonomy('category_models', array('appliances'), $args);
    // register_taxonomy('city_states_zips', array('quote_request'), $args2);
    /** CITIES, STATES AND ZIP CODES * */
	flush_rewrite_rules( false );
}

add_action('init', 'wattage_calculator_custom_post_type');
function plugin_add_custom_boxes(){
	add_meta_box( "shipper_info", __("Shipper Detail", "vehicle"), "shipper_tab", "quote_request", "normal", "core", null);
	add_meta_box('transportation_info', __("Transportation Detail", "vehicle"), 'transportation_tab', "quote_request", 'normal',"core", null);
	add_meta_box( "order_pickup_dropoff", __("Pickup Dropoff Detail", "vehicle"), "order_pickup_dropoff_tab", "order_request", "normal", "core", null);
	add_meta_box( "order_payment_billing", __("Payment & Billing Detail", "vehicle"), "order_payment_billing_tab", "order_request", "normal", "core", null);
	add_meta_box( "order_shipper_info", __("Shipper Detail", "vehicle"), "order_shipper_tab", "order_request", "normal", "core", null);
	add_meta_box('order_transportation_info', __("Transportation Detail", "vehicle"), 'order_transportation_tab', "order_request", 'normal',"core", null);
}
function order_pickup_dropoff_tab(){ 
 global $post; 
 $order_info = get_post_meta($post->ID, "order_info", true);
 $order_info = json_decode($order_info,true);
 	    if ($order_info['pickup_by'] === "me") {
            $contact_name = $order_info['full_name'];
            $contact_email  = $order_info['email_quote'];
            $originphone = $order_info['phone'];
        }
        // someone else
        else {
            $contact_name = $order_info['pickup_name'];
            $contact_email  = '';
            $originphone = $order_info['pickup_phone'];
        }
		if ($lead_info['dropoff_by'] === "me") {
            $dcontact_name = $order_info['full_name'];
            $dcontact_email  = $order_info['email_quote'];
            $destinationphone = $order_info['phone'];
        }
        // someone else
        else {
            $dcontact_name = $order_info['dropoff_name'];
            $dcontact_email  = '';
            $destinationphone = $order_info['dropoff_phone'];
        }
// echo "<pre>".print_r($order_info, 1)."</pre>";
 ?>
<div id="order_pickup_dropoff_tab" >
  <table border='0' width="100%">
	<tr><td> 
	<?php _e("Pickup Date", "vehicle"); ?>
    <div><b><?php echo $order_info['pickup_date']; ?></b></div>
	</td></tr>
	<tr><td width="50%"> 
	<?php _e("Pickup by", "vehicle"); ?>
    <div><b><?php echo $contact_name; ?></b></div>
	</td><td> 
	<?php _e("Phone", "vehicle"); ?>
    <div><b><?php echo $originphone; ?></b></div>
	</td></tr>
	<tr><td> 
	<?php _e("Pickup Address", "vehicle"); ?>
    <div><b><?php echo $order_info['pickup_address']; ?></b></div>
	<div><span>City: <b><?php echo $order_info['city_from']; ?></b></span>
	<span>State: <b><?php echo $order_info['state_from']; ?></b></span>
	<span>Zipcode: <b><?php echo $order_info['zip_code_from']; ?></b></span></div>
	</td></tr>
	<tr><td> 
	<?php _e("Dropoff by", "vehicle"); ?>
    <div><b><?php echo $dcontact_name; ?></b></div>
	</td><td> 
	<?php _e("Phone", "vehicle"); ?>
    <div><b><?php echo $destinationphone; ?></b></div>
	</td></tr>
	<tr><td> 
	<?php _e("Dropoff Address", "vehicle"); ?>
    <div><b><?php echo $order_info['dropoff_address']; ?></b></div>
	<div><span>City: <b><?php echo $order_info['city_to']; ?></b></span>
	<span>State: <b><?php echo $order_info['state_to']; ?></b></span>
	<span>Zipcode: <b><?php echo $order_info['zip_code_to']; ?></b></span></div>
	</td></tr>
	<tr><td> 
	<u><?php _e("Instructions", "vehicle"); ?></u>
    <div><?php echo $order_info['instructions']; ?></div>
	</td></tr>
	
  </table> 
</div>
<?php
}
function order_payment_billing_tab(){ 
 global $post; 
 $order_info = get_post_meta($post->ID, "order_info", true);
 $order_info = json_decode($order_info,true);
 //echo "<pre>".print_r($order_info, 1)."</pre>";
 if ($order_info['billing_address'] === "from_address") {
	$address_1 = $order_info['pickup_address'];
	$address_city = $order_info['city_from'];
	$address_state = $order_info['state_from'];
	$address_zipcode = $order_info['zip_code_from'];
 }
// shipper details to
 else if ($order_info['billing_address'] === "to_address") {
	$address_1 = $order_info['dropoff_address'];
	$address_city = $order_info['city_to'];
	$address_state = $order_info['state_to'];
	$address_zipcode = $order_info['zip_code_to'];
 }
// shipper details something else
 else if ($order_info['billing_address'] === "other_address") {
	$address_1 = $order_info['billing_address_other'];
	$address_city = $order_info['billing_city_other'];
	$address_state = $order_info['billing_state_other'];
	$address_zipcode = $order_info['billing_zip_other'];
 }
 ?>
 <div id="order_payment_billing_tab" >
   <table border='0' width="100%">
	<tr><td colspan="2"> 
	<?php _e("Billing Address", "vehicle"); ?>
    <div><b><?php echo $address_1; ?></b></div>
	<div><span>City: <b><?php echo $address_city; ?></b></span>
	<span>State: <b><?php echo $address_state; ?></b></span>
	<span>Zipcode: <b><?php echo $address_zipcode; ?></b></span></div>
	</td></tr>
	<tr><td colspan="2"> 
	<?php _e("Card Number", "vehicle"); ?>
    <div><b><?php echo $order_info['card_number']; ?></b></div>
	</td></tr>
	<tr><td width="50%" class="border-right"> 
	<?php _e("Expiry Month", "vehicle"); ?>
    <div><b><?php echo $order_info['expiry_month']; ?></b></div>
	</td><td> 
	<?php _e("Expiry Year", "vehicle"); ?>
    <div><b><?php echo $order_info['expiry_year']; ?></b></div>
	</td></tr>
	<tr><td colspan="2"> 
	<?php _e("Card Full Name", "vehicle"); ?>
    <div><b><?php echo $order_info['card_full_name']; ?></b></div>
	</td></tr>
   </table>
 </div> 
<?php
}
function order_shipper_tab(){ 
 global $post; 
 $order_info = get_post_meta($post->ID, "order_info", true);
 $order_info = json_decode($order_info,true);
 //echo "<pre>".print_r($quotation_info, 1)."</pre>";
 ?>
 <div id="shipper_tab" >
   <table border='0' width="100%">
	<tr><td colspan="2"> 
	<?php _e("Full name", "vehicle"); ?>
    <div><b><?php echo $order_info['full_name']; ?></b></div>
	</td></tr>
	<tr><td colspan="2"> 
	<?php _e("Email", "vehicle"); ?>
    <div><b><?php echo $order_info['email_quote']; ?></b></div>
	</td></tr>
	<tr><td colspan="2"> 
	<?php _e("Phone", "vehicle"); ?>
    <div><b><?php echo $order_info['phone']; ?></b></div>
	</td></tr>
	<tr><td width="50%" class="border-right"> 
	<?php _e("From", "vehicle"); ?>
    <div><b><?php echo $order_info['zip_from']; ?></b></div>
	</td><td> 
	<?php _e("To", "vehicle"); ?>
    <div><b><?php echo $order_info['zip_to']; ?></b></div>
	</td></tr>
	<tr><td width="50%" class="border-right"> 
	<?php _e("Price", "vehicle"); ?>
    <div><b>$<?php echo $order_info['estimated_price']; ?></b></div>
	</td><td> 
	<?php _e("Deposit", "vehicle"); ?>
    <div><b>$<?php echo $order_info['deposited_price']; ?></b></div>
	</td></tr>
   </table>
 </div>
<?php 	
}
function order_transportation_tab() {
	global $post;
	// Noncename needed to verify where the data originated
	echo '<input type="hidden" name="eventmeta_noncename" id="eventmeta_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	// Get the location data if its already been entered
 $order_info = get_post_meta($post->ID, "order_info", true);
 $order_info = json_decode($order_info,true);
 $vehicle_info = $order_info['vehicle_info'];
?>
 <div id="shipper_tabs">
   <table border='0' width="100%">
	<tr><td width="50%" class="border-right"> 
	<?php _e("Transport Type", "vehicle"); ?>
    <div><b><?php echo $order_info['transport_type']; ?></b></div>
	</td><td> 
	<?php _e("Is it Operable", "vehicle"); ?>
    <div><b><?php echo (($order_info['operable']==1)? 'Yes' : 'No'); ?></b></div>
	</td></tr>
	<tr><td colspan="2"> 
	<?php _e("Available Date", "vehicle"); ?>
    <div><b><?php echo $order_info['estimate_time']; ?></b></div>
	</td></tr>
	<tr><td colspan="2"> 
	<?php _e("Codition", "vehicle"); ?>
    <div><b><?php echo "Runnig"; ?></b></div>
	</td></tr>
	<tr><td width="50%" class="border-right"> 
	<?php _e("Origin", "vehicle"); ?>
	<hr/>
    <div>City: <?php echo $order_info['city_from']; ?></div>
	<div>State: <?php echo $order_info['state_from']; ?></div>
	<div>Zipcode: <?php echo $order_info['zip_code_from']; ?></div>
	</td><td> 
	<?php _e("Destination", "vehicle"); ?>
	<hr/>
    <div>City: <?php echo $order_info['city_to']; ?></div>
	<div>State: <?php echo $order_info['state_to']; ?></div>
	<div>Zipcode: <?php echo $order_info['zip_code_to']; ?></div>
	</td></tr>
   </table>
   <p><b>Vehicle Details</b></p>
   <hr/>
   <table border='0' width="100%">
   <?php foreach($vehicle_info as $vehicle){ ?>
		<tr><td><strong>Vehicle:&nbsp;&nbsp;&nbsp;</strong> <span id="txt_vehicle"><?php echo $vehicle['v_make']." ".$vehicle['v_model']." ".$vehicle['v_year']; ?></span></td></tr>
	<?php } ?>
   </table>
 </div>
<?php
}
function shipper_tab(){ 
 global $post; 
 $quotation_info = get_post_meta($post->ID, "quotation_info", true);
 $quotation_info = json_decode($quotation_info,true);
 //echo "<pre>".print_r($quotation_info, 1)."</pre>";
 ?>
 <div id="shipper_tab" >
   <table border='0' width="100%">
	<tr><td colspan="2"> 
	<?php _e("Full name", "vehicle"); ?>
    <div><b><?php echo $quotation_info['full_name']; ?></b></div>
	</td></tr>
	<tr><td colspan="2"> 
	<?php _e("Email", "vehicle"); ?>
    <div><b><?php echo $quotation_info['email_quote']; ?></b></div>
	</td></tr>
	<tr><td colspan="2"> 
	<?php _e("Phone", "vehicle"); ?>
    <div><b><?php echo $quotation_info['phone']; ?></b></div>
	</td></tr>
	<tr><td width="50%" class="border-right"> 
	<?php _e("From", "vehicle"); ?>
    <div><b><?php echo $quotation_info['zip_from']; ?></b></div>
	</td><td> 
	<?php _e("To", "vehicle"); ?>
    <div><b><?php echo $quotation_info['zip_to']; ?></b></div>
	</td></tr>
	<tr><td width="50%" class="border-right"> 
	<?php _e("Price", "vehicle"); ?>
    <div><b>$<?php echo $quotation_info['estimated_price']; ?></b></div>
	</td><td> 
	<?php _e("Deposit", "vehicle"); ?>
    <div><b>$<?php echo $quotation_info['deposited_price']; ?></b></div>
	</td></tr>
   </table>
 </div>
<?php 	
}
function transportation_tab() {
	global $post;
	// Noncename needed to verify where the data originated
	echo '<input type="hidden" name="eventmeta_noncename" id="eventmeta_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	// Get the location data if its already been entered
 $quotation_info = get_post_meta($post->ID, "quotation_info", true);
 $quotation_info = json_decode($quotation_info,true);
 $vehicle_info = $quotation_info['vehicle_info'];
?>
 <div id="transportation_tab">
   <table border='0' width="100%">
	<tr><td width="50%" class="border-right"> 
	<?php _e("Transport Type", "vehicle"); ?>
    <div><b><?php echo $quotation_info['transport_type']; ?></b></div>
	</td><td> 
	<?php _e("Is it Operable", "vehicle"); ?>
    <div><b><?php echo (($quotation_info['operable']==1)? 'Yes' : 'No'); ?></b></div>
	</td></tr>
	<tr><td colspan="2"> 
	<?php _e("Available Date", "vehicle"); ?>
    <div><b><?php echo $quotation_info['estimate_time']; ?></b></div>
	</td></tr>
	<tr><td> 
	<?php _e("Codition", "vehicle"); ?>
    <div><b><?php echo "Runnig"; ?></b></div>
	</td><td> 
	<?php _e("Insurance", "vehicle"); ?>
    <div><b><?php echo "Included"; ?></b></div>
	</td></tr>
	<tr><td width="50%" class="border-right"> 
	<?php _e("Origin", "vehicle"); ?>
	<hr/>
    <div>City: <?php echo $quotation_info['city_from']; ?></div>
	<div>State: <?php echo $quotation_info['state_from']; ?></div>
	<div>Zipcode: <?php echo $quotation_info['zip_code_from']; ?></div>
	</td><td> 
	<?php _e("Destination", "vehicle"); ?>
	<hr/>
    <div>City: <?php echo $quotation_info['city_to']; ?></div>
	<div>State: <?php echo $quotation_info['state_to']; ?></div>
	<div>Zipcode: <?php echo $quotation_info['zip_code_to']; ?></div>
	</td></tr>
   </table>
   <p><b>Vehicle Details</b></p>
   <hr/>
   <table border='0' width="100%">
   <?php foreach($vehicle_info as $vehicle){ ?>
		<tr><td><strong>Vehicle:&nbsp;&nbsp;&nbsp;</strong> <span id="txt_vehicle"><?php echo $vehicle['v_make']." ".$vehicle['v_model']." ".$vehicle['v_year']; ?></span></td></tr>
	<?php } ?>
   </table>
 </div>
<?php
}
add_action( 'add_meta_boxes', 'plugin_add_custom_boxes' );
function wp_custom_post_force_type_private($post) {
  if ($post['post_status'] != 'trash' && (($post['post_type'] == 'generstors') || ($post['post_type'] == 'appliances'))) {
    $post['post_status'] = 'private';
  }
  return $post;
}
add_filter('wp_insert_post_data', 'wp_custom_post_force_type_private');