<?php
function wattage_calculator_plugin_admin_menu() {
    add_menu_page(
        'Wattage Calculator',
        'Wattage Calculator',
        'manage_options',
        'wattage-calculator',
        '', // Callback, leave empty
        'dashicons-calendar',
        5 // Position
    );
	add_submenu_page( 'wattage-calculator', 'Category & Models', 'Category & Models', 'manage_options', 'edit-tags.php?taxonomy=category_models');
}// function

add_action( 'admin_menu', 'wattage_calculator_plugin_admin_menu' );
add_action( 'parent_file', 'menu_highlight' );
function menu_highlight( $parent_file ) {
        global $current_screen;

        $taxonomy = $current_screen->taxonomy;
        if ( $taxonomy == 'category_models' ) {
            $parent_file = 'wattage-calculator';
        }

        return $parent_file;
} // function

if(!function_exists("wattage_calculator_custom_post_type")){
    function wattage_calculator_custom_post_type() {
    	//********************************************
    	//	Register the post type
    	//***********************************************************
		$generstors = array(
    	  'labels'              => array(
				  'name' => __('Generstors'),
				  'singular_name'       => __('Generstor'),
				  'add_new'			 	=> __('Add New', 'americaedu'),
				  'add_new_item'		=> __('Add New Generstor', 'americaedu'),
				  'edit_item'			=> __('Edit Generstor', 'americaedu'),
				  'new_item'			=> __('New Generstor', 'americaedu'),
				  'all_items'			=> __('All Generstors', 'welldone'),
				  'search_items'		=> __('Search Generstors', 'welldone'),
				  'view_item' 		 	=> __('View Generstors', 'americaedu'),
				  'not_found'          	=> __('No Generstors found', 'welldone'),
				  'not_found_in_trash' 	=> __('No Generstors found in Trash',  'welldone'),
				  'menu_name'			=> __('Generstors', 'welldone')
				  ),
    	  'public'              => true,
    	  'publicly_queryable' 	=> true,
    	  'show_ui'            	=> true, 
    	  'show_in_menu' 	    => 'wattage-calculator',
    	  'query_var'          	=> true,
    	  'rewrite' 	        => array( 'slug' => 'generstors','with_front'=> true,'post' => true ),
    	  'capability_type'    	=> 'post',
    	  'has_archive'        	=> true, 
    	  'hierarchical'       	=> false,
		  'exclude_from_search' => false,
    	  'taxonomies' 			=> array('generstors_category'), 
    	  'menu_position'      	=> null,
    	  'supports'			=> array('title', 'discussion', 'thumbnail' )
    	); 
      
    	register_post_type( 'generstors', $generstors );
        $appliances = array(
      'labels' => array(
          'name' => __('Appliances'),
          'singular_name' => __('Appliances'),
		  'add_new'			 	=> __('Add New', 'americaedu'),
		  'add_new_item'		=> __('Add New Appliance', 'americaedu'),
		  'edit_item'			=> __('Edit Appliance', 'americaedu'),
		  'new_item'			=> __('New Appliance', 'americaedu'),
    	  'all_items'			=> __('All Appliances', 'welldone'),
    	  'search_items'		=> __('Search Appliances', 'welldone'),
		  'view_item' 		 	=> __('View Appliances', 'americaedu'),
    	  'not_found'          	=> __('No Appliances found', 'welldone'),
    	  'not_found_in_trash' 	=> __('No Appliances found in Trash',  'welldone'),
    	  'menu_name'			=> __('Appliances', 'welldone')
        ),
          'public'              => true,
    	  'publicly_queryable' 	=> true,
    	  'show_ui'            	=> true, 
    	  'show_in_menu' 	    => 'wattage-calculator',
    	  'query_var'          	=> true,
    	  'rewrite' 	        => array( 'slug' => 'appliances','with_front'=> true,'post' => true ),
    	  'capability_type'    	=> 'post',
    	  'has_archive'        	=> true, 
    	  'hierarchical'       	=> false,
		  'exclude_from_search' => false,
    	  'taxonomies' 			=> array('category_models'), 
    	  'menu_position'      	=> null,
    	  'supports'			=> array('title', 'discussion', 'thumbnail' )
    );

    // registering the post type
    register_post_type('appliances', $appliances);
	    /** CATEGORY AND MODELS * */
    // Add new taxonomy, make it hierarchical (like categories)
    $labels = array(
        'name' => _x('Category & Models', 'taxonomy general name', 'textdomain'),
        'singular_name' => _x('Category & Models', 'taxonomy singular name', 'textdomain')
    );

    // preaparing arguments
    $args = array(
        'hierarchical' => true,
        'labels' => $labels,
        'publicly_queryable' 	=> true,
    	'show_ui'            	=> true, 
        'query_var' => true,
        'rewrite' => array('slug' => 'category_models'),
    );

    register_taxonomy('category_models', array('appliances'), $args);
    // register_taxonomy('city_states_zips', array('quote_request'), $args2);
    /** CITIES, STATES AND ZIP CODES * */
	flush_rewrite_rules( false );
    } //function
    add_action( 'init', 'wattage_calculator_custom_post_type' );
}// if
add_action( 'add_meta_boxes', 'wattage_calculator_custom_post_meta_boxes' );

function wattage_calculator_custom_post_meta_boxes(){
 $post_type = "generstors";//array("post", "page");
 add_meta_box( "generstors_details", __("Generstors Details", "americaedu"), "generstors_details_tabs", "generstors", "normal", "core", null);
 add_meta_box( "appliances_details", __("Appliances Details", "americaedu"), "appliances_details_tabs", "appliances", "normal", "core", null);
}
/* Generstors Tab */
function generstors_details_tabs(){ 
global $post; 
	$generstors_key = get_post_meta($post->ID, "generstors_key", true); 
	$args = array(
    'posts_per_page' => -1,
    'post_type' => 'generstors',
    'post_status'    => 'publish',
    'meta_query' => array(
        'relation' => 'AND',
            array(
                'key' => 'gstarting_watt',
                'value' => 225,
                'compare' => '>=',
				'type' => NUMERIC
            ),
            array(
                'key' => 'grunning_watt',
                'value' => 225,
                'compare' => '>=',
				'type' => NUMERIC
            )
        ),
    );

$search_result = new WP_Query( $args );
echo "<pre>".print_r($search_result, 1)."</pre>"; ?>
 <div id="detail_tabs">
    <table border='0'>
	<tr><td>Starting Watt</td><td><input type="text"  name="starting_watt" value="<?php echo (isset($generstors_key['starting_watt']) && !empty($generstors_key['starting_watt']) ? $generstors_key['starting_watt'] : ''); ?>" /></td></tr>
	<tr><td>Running Watt</td><td><input type="text" name="running_watt" value="<?php echo (isset($generstors_key['running_watt']) && !empty($generstors_key['running_watt']) ? $generstors_key['running_watt'] : ''); ?>" /></td></tr>
	<tr><td>Review Link</td><td><input type="text" name="review_link" value="<?php echo (isset($generstors_key['review_link']) && !empty($generstors_key['review_link']) ? $generstors_key['review_link'] : ''); ?>" /></td></tr>
	<tr><td>Buying Link</td><td><input type="text"  name="buying_link" value="<?php echo (isset($generstors_key['buying_link']) && !empty($generstors_key['buying_link']) ? $generstors_key['buying_link'] : ''); ?>" /></td></tr>
   </table>
  </div>
<?php 	
}// function

/* Appliances Tab */
function appliances_details_tabs(){ 
global $post; 
	$appliances_key = get_post_meta($post->ID, "appliances_key", true); 
	//echo '<pre>'.print_r($appliances_key, 1).'</pre>';
	?>
 <div id="appliances_tabs">
    <table border='0' class="appliances-info">
	<tr><th>Starting Watt</th><th>Running Watt</th><th>Voltage</th><th>Type</th><th><th></tr>
	<tr><td><?php if(isset($appliances_key['starting_watt']) && !empty($appliances_key['starting_watt'])){
	  foreach($appliances_key['starting_watt'] as $value): ?>
	<input type="text"  name="starting_watt[]" value="<?php echo $value; ?>" required autocomplete='off' /><div>If no value put 0</div><?php endforeach; }else{ ?><input type="text"  name="starting_watt[]" value="" required autocomplete='off' /><div>If no value put 0</div><?php } ?></td><td><?php if(isset($appliances_key['running_watt']) && !empty($appliances_key['starting_watt'])){
	  foreach($appliances_key['running_watt'] as $value): ?><input type="text" name="running_watt[]" value="<?php echo $value; ?>" required autocomplete='off' /><div>&nbsp;</div><?php endforeach; }else{  ?><input type="text" name="running_watt[]" value="" required autocomplete='off' /><div>&nbsp;</div><?php } ?></td><td><?php if(isset($appliances_key['running_watt']) && !empty($appliances_key['item_voltage'])){
	  foreach($appliances_key['item_voltage'] as $value): ?><input type="text"  name="item_voltage[]" value="<?php echo $value; ?>" /><div>&nbsp;</div><?php endforeach; }else{ ?><input type="text"  name="item_voltage[]" value="120" /><div>&nbsp;</div><?php } ?></td><td><?php if(isset($appliances_key['item_type']) && !empty($appliances_key['item_type'])){
	  foreach($appliances_key['item_type'] as $value): ?><input type="text"  name="item_type[]" value="<?php echo $value; ?>" autocomplete='off'/><div>If no value leave empty</div><?php endforeach; }else{ ?><input type="text"  name="item_type[]" value="" autocomplete='off'/><div>If no value leave empty</div><?php } ?></td></tr>
   </table>
   <div class="more-type ">more type</div>
  </div>
  <?php 	
}// function

//********************************************
//	Save custom meta fields
//***********************************************************
function wattage_calculator_save_custom_meta($post_id){
  if(get_post_type() == "generstors"){
	 if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
	   return $post_id;
	 }else {
	   generstor_meta_box_data_save($post_id);
	 }   
  }elseif(get_post_type() == "appliances"){
	 if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
	   return $post_id;
	 }else {
	   appliance_meta_box_data_save($post_id);
	 }
  }
}// function close

add_action('save_post', 'wattage_calculator_save_custom_meta');

function generstor_meta_box_data_save($post_id){
$generstor['starting_watt'] = (isset($_POST['starting_watt']) && !empty($_POST['starting_watt']) ? $_POST['starting_watt'] : "");
$generstor['running_watt'] = (isset($_POST['running_watt']) && !empty($_POST['running_watt']) ? $_POST['running_watt'] : "");
$generstor['review_link'] = (isset($_POST['review_link']) && !empty($_POST['review_link']) ? $_POST['review_link'] : "");
$generstor['buying_link'] = (isset($_POST['buying_link']) && !empty($_POST['buying_link']) ? $_POST['buying_link'] : "");

		update_post_meta((int)$post_id, "generstors_key", $generstor);
		update_post_meta((int)$post_id, "gstarting_watt", $generstor['starting_watt']);
		update_post_meta((int)$post_id, "grunning_watt", $generstor['running_watt']);
}//function close

function appliance_meta_box_data_save($post_id){
$appliance['starting_watt'] = (isset($_POST['starting_watt']) && !empty($_POST['starting_watt']) ? array_map( 'sanitize_text_field', $_POST[ 'starting_watt' ] ) : "");
$appliance['running_watt'] = (isset($_POST['running_watt']) && !empty($_POST['running_watt']) ? array_map( 'sanitize_text_field', $_POST[ 'running_watt' ] ) : "");
$appliance['item_type'] = (isset($_POST['item_type']) && !empty($_POST['item_type']) ? array_map( 'sanitize_text_field', $_POST[ 'item_type' ] ) : "");
$appliance['item_voltage'] = (isset($_POST['item_voltage']) && !empty($_POST['item_voltage']) ? array_map( 'sanitize_text_field', $_POST[ 'item_voltage' ] ) : "");

		update_post_meta((int)$post_id, "appliances_key", $appliance);
		update_post_meta((int)$post_id, "astarting_watt", $appliance['starting_watt']);
		update_post_meta((int)$post_id, "arunning_watt", $appliance['running_watt']);
}//function close
// Add the custom columns to the book post type:
add_filter( 'manage_appliances_posts_columns', 'set_custom_edit_appliances_columns' );
function set_custom_edit_appliances_columns($columns) {
$columns['cb'] = __( '&lt;input type="checkbox" />', 'wattage' );
$columns['title'] = __( 'Appliances', 'wattage' );
    $columns['starting_watt'] = __( 'Starting Watt', 'wattage' );
    $columns['running_watt'] = __( 'Running Watt', 'wattage' );
    $columns['item_voltage'] = __( 'Item Voltage', 'wattage' );
    $columns['item_type'] = __( 'Item Type', 'wattage' );
$columns['date'] = __( 'Date', 'wattage' );
		
	return $columns;
}

// Add the data to the custom columns for the book post type:
add_action( 'manage_appliances_posts_custom_column' , 'custom_appliances_column', 10, 2 );
function custom_appliances_column( $column, $post_id ) {
        $appliances_key = get_post_meta((int)$post_id, "appliances_key", true);
		$starting_watt = $running_watt = $item_voltage = $item_type = '';
	 	foreach($appliances_key['item_type'] as $key => $value):
	       $starting_watt .= $appliances_key['starting_watt'][$key].", ";
	       $running_watt .= $appliances_key['running_watt'][$key].", ";
		   $item_voltage .= $appliances_key['item_voltage'][$key].", ";
		   $item_type .= $value.", ";
		endforeach;
    switch ( $column ) {
        case 'starting_watt' :
            echo rtrim($starting_watt, ', ');
            break;
        case 'running_watt' :
            echo rtrim($running_watt, ', ');
            break;
        case 'item_voltage' :
            echo rtrim($item_voltage, ', '); 
            break;
		case 'item_type' :
            echo rtrim($item_type, ', ');
            break;
    }
}
// Add the custom columns to the book post type:
add_filter( 'manage_generstors_posts_columns', 'set_custom_edit_generstors_columns' );
function set_custom_edit_generstors_columns($columns) {
	$columns = array(
		'cb' => '&lt;input type="checkbox" />',
		'title' => __( 'Generstors' ),
		'starting_watt' => __( 'Starting Watt' ),
		'running_watt' => __( 'Running Watt' ),
		'review_link' => __( 'Review Link' ),
		'buying_link' => __( 'Buying Link' ),
		'date' => __( 'Date' )
	);
	return $columns;
}
// Add the data to the custom columns for the book post type:
add_action( 'manage_generstors_posts_custom_column' , 'custom_generstors_column', 10, 2 );
function custom_generstors_column( $column, $post_id ) {
        $generstors_key = get_post_meta((int)$post_id, "generstors_key", true);

	       $starting_watt = $generstors_key['starting_watt'];
	       $running_watt = $generstors_key['running_watt'];
		   $review_link = $generstors_key['review_link'];
		   $buying_link = $generstors_key['buying_link'];

    switch ( $column ) {
        case 'starting_watt' :
            echo $starting_watt;
            break;
        case 'running_watt' :
            echo $running_watt;
            break;
        case 'review_link' :
            echo esc_url($review_link); 
            break;
		case 'buying_link' :
            echo esc_url($buying_link);
            break;
    }
}