<?php 
function wattage_calculator_shortcode_function($attr) {
$args = shortcode_atts(array('next_page' => ''),$attr);

$output ="";
$loop ="";
global $wpdb, $wp_query, $current_user;
ob_start();
$args = array(
	'taxonomy' => 'category_models',
	'child_of' => 0,
	'parent' => 0,
	'orderby' => 'name',
	'show_count' => 0,
	'pad_counts' => 0,
	'hierarchical' => 1,
	'title_li' => '',
	'hide_empty' => 0
);
$categories = get_categories( $args );
$cat_n = count($categories); $i = 1;
if($cat_n > 0)  $col_size = 12/$cat_n;
?>
<div id="step-one">

<div class="step">Step 1</div>
<div class="header-title">How will you use the generator, primarily?</div>
<div class="row">
<?php
//echo "<pre>".print_r($categories, 1)."</pre>";

foreach($categories as $cat): 
$i++;
$t_id = $cat->term_id;
$term_meta = get_option( "category_models_$t_id" );
$image_url = esc_attr( $term_meta['image'] ) ? esc_attr( $term_meta['image'] ) : ''; 
$taxonomy_description = get_option( "category_models_taxonomy_description_$t_id" );
?>
<div class="col-md-<?php echo $col_size; ?>" >
<label><input type="radio" name="cat_name" value="<?php echo $cat->term_id; ?>" />
<img src="<?php echo $image_url; ?>" >
</label>
<h2><?php echo $cat->cat_name; ?></h2>
<div class="description"><?php echo $taxonomy_description; ?></div>

</div><!--class="col-md- -->
<?php
endforeach;
?>
</div><!--class="row"-->
<div class="row pull-right">
<input type="button" class="btn btn-large btn-primary pull-right" name="go-step-two" value="Next" />
</div><!--row-->
</div> <!--id="step-one"-->

<!--template for step 2-->
<div id="step-two">
<b>Step 2</b>
<div>What do you want to power?</div>

<div class="row">
 <div class="col-md-6 term-applience">
 
 </div>
 <div class="col-md-6 other-applience">
 <ul class="other-appliences-list">
  <li><div class="appliences"><div>Other Items</div></div><div class="wattage"><div>Wattage</div></div></li>
  <li><div class="appliences"><input type="text" name="others_name[]"  /></div>  <div class="wattage"><input type="text" name="start_watt[]" value="" /><input type="text" name="running_watt[]" value="" /></div></li>
  <li><div class="appliences"><input type="text" name="others_name[]"  /></div>  <div class="wattage"><input type="text" name="start_watt[]" value="" /><input type="text" name="running_watt[]" value="" /></div></li>
  <li><div class="appliences"><input type="text" name="others_name[]"  /></div>  <div class="wattage"><input type="text" name="start_watt[]" value="" /><input type="text" name="running_watt[]" value="" /></div></li>
  <li><div class="appliences"><input type="text" name="others_name[]"  /></div>  <div class="wattage"><input type="text" name="start_watt[]" value="" /><input type="text" name="running_watt[]" value="" /></div></li>
 </ul>
 </div><!--other-applience-->
</div><!--row-->
<div class="row pull-right">
<input type="button" class="btn btn-large btn-primary pull-right" name="go-step-three" value="Calculate Wattage" />
</div><!--row-->
</div><!--id="step-two"-->

<!--template for step 3-->
<div id="step-three">
<div>Your Power Needs Are:</div>
<div class="row">
 <div class="col-md-8 applience-data">
   <div id="data-table"></div>
   <em>Note: All wattages are estimates. Your application's exact wattage may vary.</em>
<input type="button" class="btn btn-large btn-primary" name="go-step-two" value="Change Selected Appliences" />
<h4>Recommendations</h4>
<p>You need a generator with the following capabilities:</p> 
<div>Minimum starting wattage: <b id="recomended">2716</b></div>
<div>Maximum wattage: <b id="maximum">3040</b></div>
<h4>Recommended models:</h4>
<div id="recommended-model"></div>
 </div><!--col-md-8-->
 <div class="col-md-4">
   <div class="other-data">
    <h4>Recommended reading:</h4>
	<div><a href="#">Home back up power tips</a></div>
	<div><a href="#">Connecting a generator to your home</a></div>
	<div><a href="#">Power Management: get more power from a smaller generator</a></div>
   </div>
 </div>
</div><!--class="row"-->
</div><!--id="step-three"-->
<?php
return ob_get_clean();
}
add_shortcode( 'wattage_calculator', 'wattage_calculator_shortcode_function');

add_action('wp_ajax_nopriv_get_appliences_info', 'get_appliences_info');
add_action('wp_ajax_get_appliences_info', 'get_appliences_info');
 
function get_appliences_info() {
	global $wpdb; //get access to the WordPress database object variable
	//get names of all businesses
	$output = $loop = '';
	$term_id = stripslashes($_POST['term_id']); //escape for use in LIKE statement

$args = array(
'posts_per_page' => -1,
'post_type' => 'appliances',
'post_status'    => 'publish',
'tax_query' => array(
    array(
    'taxonomy' => 'category_models',
    'field' => 'term_id',
    'terms' => $term_id
     )
  )
);
$search_result = new WP_Query( $args );
//echo "<pre>".print_r($search_result, 1)."</pre>";
$cat_n = count($search_result);
$output .= '<div class="qnt">Quantity</div>
              <ul class="appliences-list">';
if ( $search_result->have_posts() ) :
 while ( $search_result->have_posts() ) : $search_result->the_post();
 $pid = get_the_ID();
 $title = get_the_title();
 $appliances_key = get_post_meta((int)$pid, "appliances_key", true);
 $starting_watt = $appliances_key['starting_watt'][0];
 $running_watt = $appliances_key['running_watt'][0];
 $item_type = '';
 if(isset($appliances_key['item_type']) && !empty($appliances_key['item_type'])){
  if(empty($appliances_key['item_type'][0])){
    $item_type = '';
  }else{
  $item_type = '<select name="item_type" >';
	foreach($appliances_key['item_type'] as $key => $value):
	$astarting_watt = $appliances_key['starting_watt'][$key];
	$arunning_watt = $appliances_key['running_watt'][$key];
	$item_type .= '<option value="'.$value.'" data-astarting_watt="'.$astarting_watt.'" data-arunning_watt="'.$arunning_watt.'" >'.$value.'</option>';
	endforeach;
  $item_type .= '</select>'; 
  }
 }

  $loop .= '<li><label class="appliences-name" ><input type="checkbox" value="'.$pid.'"  data-name="'.$title.'" data-starting_watt="'.$starting_watt.'" data-running_watt="'.$running_watt.'" name="selected_appliences[]" />'.$title.'</label><input type="text" name="appliences_qnt[]" value="1" /><div>'.$item_type.'</div></li>';
endwhile;
    wp_reset_query();
	wp_reset_postdata();
else :
	$loop .= '<li>Sorry, no appliences matched your criteria.</li>';
endif;
$output .= $loop .'</ul>';
    wp_send_json_success($output);
	die(); //stop "0" from being output
}
add_action('wp_ajax_nopriv_get_recommended_generator', 'get_recommended_generator');
add_action('wp_ajax_get_recommended_generator', 'get_recommended_generator');
 
function get_recommended_generator() {
	global $wpdb; //get access to the WordPress database object variable
	//get names of all businesses
	$output = $loop = '';
	$starting_watt = stripslashes($_POST['starting_watt']); //escape for use in LIKE statement
	$running_watt = stripslashes($_POST['running_watt']);
	$recommended_watt = stripslashes($_POST['recommended_watt']);
	$args = array(
    'posts_per_page' => -1,
    'post_type' => 'generstors',
    'post_status'    => 'publish',
    'meta_query' => array(
        'relation' => 'AND',
            array(
                'key' => 'gstarting_watt',
                'value' => $recommended_watt,
                'compare' => '>=',
				'type' => NUMERIC
            ),
            array(
                'key' => 'grunning_watt',
                'value' => $running_watt,
                'compare' => '>=',
				'type' => NUMERIC
            )
        ),
    );

$search_generstors = new WP_Query( $args );
echo "<pre>".print_r($search_generstors, 1)."</pre>";
$output .= '<ul class="generstors-list">';
if ( $search_generstors->have_posts() ) :
 while ( $search_generstors->have_posts() ) : $search_generstors->the_post();
 $pid = get_the_ID();
 $title = get_the_title();
 $generstors_key = get_post_meta((int)$pid, "generstors_key", true);
 $review_link = $generstors_key['review_link'];
 $buying_link = $generstors_key['buying_link'];
 $max_starting_watt = $generstors_key['starting_watt'];
   $loop .= '<li><a href="'.$review_link.'" >'.$title.'</a>&nbsp;&nbsp;&nbsp;&nbsp;<a class="btn btn-primary" href="'.$buying_link.'">Buy now</a></li>';
endwhile;
    wp_reset_query();
	wp_reset_postdata();
else :
	$loop .= '<li>Sorry, no generstors matched your criteria.</li>';
endif;
$output .= $loop .'</ul>';
    echo $output;
	//echo $running_watt.' '.$recommended_watt;
	die(); //stop "0" from being output
}// function