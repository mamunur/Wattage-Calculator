<?php 
function wattage_calculator_shortcode_function($attr) {
$args = shortcode_atts(array('next_page' => ''),$attr);
if($args['next_page'] == '') {
    echo " Please set next step page ";
	return;
} else{
    $step2link = esc_url( get_permalink( get_page_by_title( $args['next_page'] ) ) );
}
$output ="";
$loop ="";
global $wpdb;
ob_start();
$args = array(
	'taxonomy' => 'category_models',
	'child_of' => 0,
	'parent' => 0,
	'orderby' => 'name',
	'show_count' => 0,
	'pad_counts' => 0,
	'hierarchical' => 1,
	'title_li' => '',
	'hide_empty' => 0
);
$categories = get_categories( $args );
$cat_n = count($categories); $i = 1;
if($cat_n > 0)  $col_size = 12/$cat_n;
?>
<div id="step-one">
<div class="step">Step 1</div>
<div class="header-title">How will you use the generator, primarily?</div>
<form id="first_form" action="<?php echo $step2link; ?>" method="post" >
<div class="row">
<?php
//echo "<pre>".print_r($categories, 1)."</pre>";
foreach($categories as $cat): 
$i++;
$t_id = $cat->term_id;
$term_meta = get_option( "category_models_$t_id" );
$image_url = esc_attr( $term_meta['image'] ) ? esc_attr( $term_meta['image'] ) : ''; 
$taxonomy_description = get_option( "category_models_taxonomy_description_$t_id" );
?>
<div class="col-md-<?php echo $col_size; ?>" >
<label><input type="radio" name="cat_name" value="<?php echo $cat->term_id; ?>" />
<img src="<?php echo $image_url; ?>" >
</label>
<h2><?php echo $cat->cat_name; ?></h2>
<div class="description"><?php echo $taxonomy_description; ?></div>

</div><!--class="col-md- -->
<?php
endforeach;
?>
</div><!--class="row"-->
<div class="row pull-right">
<input type="submit" class="btn btn-primary pull-right" name="go-step-two" value="Next" />
</div><!--row-->
</form>
</div> <!--id="step-one"-->
<?
return ob_get_clean();
}// function

add_shortcode( 'wattage_calculator', 'wattage_calculator_shortcode_function');

function wattage_calculator_step2_shortcode_function($attr) {
$args = shortcode_atts(array('next_page' => ''),$attr);
if($args['next_page'] == '') {
    echo " Please set next step page ";
	return;
} else{
    $step3link = esc_url( get_permalink( get_page_by_title( $args['next_page'] ) ) );
}
$output ="";
$loop ="";
global $wpdb, $wp_query, $current_user;
ob_start();
$term_id = stripslashes($_POST['cat_name']);
if(empty($term_id)) $term_id = stripslashes($_GET['term_id']);
	//echo $term_id;
?>	
<div id="second-step">
<div class="step">Step 2</div>
<div class="header-title">What do you want to power?</div>
<form id="second_form" action="<?php echo $step3link; ?>" method="post" >
<div class="row">
 <div class="col-md-6 term-applience">
<?php
$args = array(
'posts_per_page' => -1,
'post_type' => 'appliances',
'post_status'    => 'publish',
'tax_query' => array(
    array(
    'taxonomy' => 'category_models',
    'field' => 'term_id',
    'terms' => $term_id
     )
  )
);
$search_result = new WP_Query( $args );
//echo "<pre>".print_r($search_result, 1)."</pre>";
$cat_n = count($search_result);
$output .= '<ul class="appliences-list">';
$output .= '<li><label class="appliences-name" >Items</label><div class="power">Power</div><div class="qty" >Quantity</div></li>';
if ( $search_result->have_posts() ) :
 while ( $search_result->have_posts() ) : $search_result->the_post();
 $pid = get_the_ID();
 $title = get_the_title();
 $appliances_key = get_post_meta((int)$pid, "appliances_key", true);
 $starting_watt = $appliances_key['starting_watt'][0];
 $running_watt = $appliances_key['running_watt'][0];
 $item_type = '';
 if(isset($appliances_key['item_type']) && !empty($appliances_key['item_type'])){
  if(empty($appliances_key['item_type'][0])){
    $item_type = '';
  }else{
  $item_type = '<select name="item_type_key_'.$pid.'" >';
	foreach($appliances_key['item_type'] as $key => $value):
	$astarting_watt = $appliances_key['starting_watt'][$key];
	$arunning_watt = $appliances_key['running_watt'][$key];
	$item_type .= '<option value="'.$key.'" >'.$value.'</option>';
	endforeach;
  $item_type .= '</select>'; 
  }
 }
  $loop .= '<li><label class="appliences-name" ><input type="checkbox" value="'.$pid.'"  name="selected_appliences[]" />'.$title.'</label><div class="power">'.$item_type.'</div><input type="text" name="appliences_qnt_'.$pid.'" value="1" /><input type="hidden" value="'.$title.'"  name="selected_appliences_title_'.$pid.'" /><input type="hidden" value=""  name="selected_appliences_key_'.$pid.'" /></li>';
endwhile;
    wp_reset_query();
	wp_reset_postdata();
else :
	$loop .= '<li>Sorry, no appliences matched your criteria.</li>';
endif;
$output .= $loop .'</ul>';
echo $output;
?> 
 </div>
 <input type="hidden" name="term_id" value="<?php echo $term_id; ?>" />
 <div class="col-md-6 other-applience">
 <ul class="other-appliences-list">
  <li><div class="appliences"><div>Other Items</div></div><div class="wattage"><div>Starting</div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<div>Ending</div></div></li>
  <li><div class="appliences"><input type="text" name="others_name[]"  /></div>  <div class="wattage"><input type="text" name="start_watt[]" value="" /><input type="text" name="end_watt[]" value="" /></div></li>
  <li><div class="appliences"><input type="text" name="others_name[]"  /></div>  <div class="wattage"><input type="text" name="start_watt[]" value="" /><input type="text" name="end_watt[]" value="" /></div></li>
  <li><div class="appliences"><input type="text" name="others_name[]"  /></div>  <div class="wattage"><input type="text" name="start_watt[]" value="" /><input type="text" name="end_watt[]" value="" /></div></li>
 </ul>
 </div><!--other-applience-->
</div><!--row-->
<div class="row pull-right">
<input type="submit" class="btn btn-large btn-primary pull-right" name="go-step-three" value="Calculate Wattage" />
</div><!--row-->
</form>
</div><!--id="step-two"-->
<?php
return ob_get_clean();
}// function
add_shortcode( 'wattage_calculator_step2', 'wattage_calculator_step2_shortcode_function');

function wattage_calculator_result_shortcode_function($attr) {
$args = shortcode_atts(array('next_page' => ''),$attr);
$appliances_info_arr = array();
$term_id = ($_POST['term_id']);
$selected_appliences = ($_POST['selected_appliences']);
$appliences_qnt = ($_POST['appliences_qnt']);
$selected_appliences_title = ($_POST['selected_appliences_title']);
$selected_appliences_key = ($_POST['selected_appliences_key']);
//echo "<pre>".print_r($selected_appliences, 1)."</pre>";
$others_name = ($_POST['others_name']);
if(!empty($selected_appliences)){
foreach($selected_appliences as $key => $pid):
 $appliances_key = get_post_meta((int)$pid, "appliances_key", true);
 $appliances_info['title'] = $_POST['selected_appliences_title_'.$pid];
 $appliances_info['qnt'] = $_POST['appliences_qnt_'.$pid];
 $key = $_POST['item_type_key_'.$pid];
 if(!isset($key) && empty($key)){
  $appliances_info['item_type'] = $appliances_key['item_type'][0];
  $appliances_info['starting_watt'] = $appliances_key['starting_watt'][0];
  $appliances_info['running_watt'] = $appliances_key['running_watt'][0];
 }else{
  $appliances_info['item_type'] = $appliances_key['item_type'][$key];
  $appliances_info['starting_watt'] = $appliances_key['starting_watt'][$key];
  $appliances_info['running_watt'] = $appliances_key['running_watt'][$key];
 }
 $appliances_info_arr[] = $appliances_info;
endforeach;
}
//echo "<pre>".print_r($others_name, 1)."</pre>";
if(!empty($others_name)){
 foreach($others_name as $k => $val):
  if(!empty($val) && !empty($_POST['start_watt'][$k])){
   $appliances_info['title'] = $val;
   $appliances_info['qnt'] = 1;
   $appliances_info['item_type'] = '';
   $appliances_info['starting_watt'] = $_POST['start_watt'][$k];
   $appliances_info['running_watt'] = $_POST['end_watt'][$k];
   $appliances_info_arr[] = $appliances_info;
  }
 endforeach;
}
//echo "<pre>".print_r($appliances_info_arr, 1)."</pre>";
$sum_of_starting_watt = $sum_of_running_watt = $recommended_watt = 0;
$starting_watt_arr = array();
if(!empty($appliances_info_arr)){
foreach ($appliances_info_arr as $item) {
    $sum_of_starting_watt += $item['starting_watt']*$item['qnt'];
	$sum_of_running_watt += $item['running_watt']*$item['qnt'];
	$starting_watt_arr[] = $item['starting_watt']*$item['qnt'];
}
$max_starting_watt = max($starting_watt_arr);
$max_index = array_search($max_starting_watt, $starting_watt_arr);
foreach ($appliances_info_arr as $key => $item) {
   if($max_index !== $key){
	$except_key_running_watt += $item['running_watt']*$item['qnt'];
   }
}
$recommended_watt = $except_key_running_watt + $max_starting_watt;
}
if($sum_of_starting_watt == 0) $sum_of_starting_watt = $sum_of_running_watt;
$output = "";
$loop = "";
global $wpdb;
$step2link = esc_url( get_permalink( get_page_by_title( 'Wattage Calculator Step2' ) ) );
ob_start();
?>
<div id="step-three">
<h3>Your Power Needs Are:</h3>
<div class="row">
 <div class="col-md-12 applience-data">
   <div id="data-table">
   <table class="selected-appliances"><tbody><tr><th>Appliance</th><th>Qty</th><th>Starting Wattage</th><th>Running Wattage</th></tr>
<?php foreach ($appliances_info_arr as $item) { ?>
<tr><td><?php echo $item['title']; ?></td><td><?php echo $item['qnt']; ?></td><td><?php echo $item['starting_watt']; ?></td><td><?php echo $item['running_watt']; ?></td></tr>
<?php } ?>
<tr><td colspan="2">Total</td><td><?php echo $sum_of_starting_watt ?></td><td><?php echo $sum_of_running_watt; ?></td></tr></tbody></table>
   </div>
<div class="row">
 <div class="col-md-8">
   <em>Note: All wattages are estimates. Your application's exact wattage may vary.</em>
 </div>
 <div class="col-md-4">
<a  class="btn btn-large btn-primary pull-right" name="go-step-two" href="<?php echo $step2link."?term_id=".$term_id; ?>" >Change appliences</a>
</div>
</div><!--class="row"-->
<div class="row margin-top-20">
 <div class="col-md-8">
<h3>Recommendations</h3>
<p>You need a generator with the following capabilities:</p> 
 </div>
 <div class="col-md-4">
<div>Recommended wattage: <b id="recomended"><?php echo $recommended_watt; ?></b></div>
<div>Maximum wattage: <b id="maximum"><?php echo $sum_of_starting_watt; ?></b></div>
</div>
</div><!--class="row"-->
<div class="row margin-top-20">
 <div class="col-md-12">
<h3>&nbsp;</h3>
<div class="recommended-model">
<?php
	$args = array(
    'posts_per_page' => -1,
    'post_type' => 'generstors',
    'post_status'    => 'publish',
    'meta_query' => array(
        'relation' => 'AND',
            array(
                'key' => 'gstarting_watt',
                'value' => $recommended_watt,
                'compare' => '>=',
                'type' => 'NUMERIC'
            ),
            array(
                'key' => 'grunning_watt',
                'value' => $sum_of_running_watt,
                'compare' => '>=',
                'type' => 'NUMERIC'
            )
        ),
    );

$search_result = new WP_Query( $args );
//echo "<pre>".print_r($search_result, 1)."</pre>";
$counting = count($search_result);
$output .= '<ul class="generstors-list">';
$output .= '<li><div class="header-image">Generator</div><div class="header-name">Appliences</div><div class="header-start">Surg Watt</div><div class="header-running">Running Watt</div><div class="header-review">Review</div><div class="header-price">Check Price</div></li>';
if ( $search_result->have_posts() ) :
 while ( $search_result->have_posts() ) : $search_result->the_post();
 $pid = get_the_ID();
 $title = get_the_title();
 $generstors_key = get_post_meta((int)$pid, "generstors_key", true);
 $review_link = esc_url($generstors_key['review_link']);
 $buying_link = esc_url($generstors_key['buying_link']);
 $starting_watt = $generstors_key['starting_watt'];
 $running_watt = $generstors_key['running_watt'];
 $url = wp_get_attachment_url( get_post_thumbnail_id((int)$pid) ); 

 $loop .= '<li><div class="generstors-image"><img src="'.$url.'" /></div><div class="generstors-name">'.$title.'</div><div class="generstors-start">'.$starting_watt.'</div><div class="generstors-running">'.$running_watt.'</div><div class="generstors-review"><a href="'.$review_link.'" class="btn btn-primary" target=�_blank� >Review Now</a></div><div class="generstors-price"><a href="'.$buying_link.'"  class="btn btn-primary" target=�_blank� >Check Now</a></div></li>';
endwhile;
    wp_reset_query();
	wp_reset_postdata();
else :
	$loop .= '<li>Sorry, no generstors matched your criteria.</li>';
endif;
$output .= $loop .'</ul>';
echo $output;
?>
</div><!--col-md-12-->
</div><!--class="row"-->
</div>
 </div><!--col-md-12-->

</div><!--class="row"-->
</div><!--id="step-three"-->
<?php
return ob_get_clean();
}// function
add_shortcode( 'wattage_calculator_result', 'wattage_calculator_result_shortcode_function');
