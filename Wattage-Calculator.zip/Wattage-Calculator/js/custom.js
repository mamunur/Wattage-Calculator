;(function($){
  "use strict";
jQuery.noConflict();
jQuery(document).ready(function($){
$('.appliences-list select[name="item_type"]').live('change', function(e) {
	e.preventDefault();
	var item_type_key = $(this).val();
	$(this).parent().find("input[name='selected_appliences_key[]']").val(item_type_key);
	//alert(item_type +" " + astarting_watt +" " + arunning_watt);
  }); // select
}); // close document
})(jQuery);

