(function($) {
  "use strict";

jQuery(document).ready( function($){
$('.date_picker').datepicker({
	dateFormat : 'dd-mm-yy', maxDate: "+9M +1D", 
});
var sl=2;
$(document).on("click", "div.more-type", function(e){
   e.preventDefault();
   var data  = '<tr><td><input type="text"  name="starting_watt[]" value="" /><div>If no value put 0</div></td><td><input type="text" name="running_watt[]" value="" /><div>&nbsp;</div></td><td><input type="text"  name="item_voltage[]" value="120" /><div>&nbsp;</div></td><td><input type="text"  name="item_type[]" value="" /><div>&nbsp;</div></td><td><span class="item-remove">x</span><div>&nbsp;</div></td></tr>';
   $('table.appliances-info').append(data);
   sl++;
   //alert("Ok");
});
$(document).on("click", ".item-remove", function(e){
   e.preventDefault();
   //alert("Ok");
   $(this).parent().parent().remove();
});

var file_portfolio_images;
$(document).on("click", "#docs_images", function(e){
	e.preventDefault();
	//alert("OK");
	var highlight_image=1009;
	var imageArray = [];
	var docs_images_input = $(".docs_images_input").val();
	var highlight_image = $(".docs_images_input").data("id");
	//alert(portfolio_image_input);
	if(docs_images_input != ''){
	  //alert(portfolio_image_input); 
	  imageArray = docs_images_input.split(',');
	  //highlight_image = imageArray[0];
	  //alert('highlight image'+imageArray[0]);
	}
	if ( file_portfolio_images ) {
	 file_portfolio_images.open();
	 return;
	}
	    // Create the media frame.
	    file_portfolio_images = wp.media.frames.file_portfolio_images = wp.media({
	      	title: jQuery( this ).data( 'uploader-title' ),
	      	button: {
	        	text: jQuery( this ).data( 'uploader-button-text' ),
	      	},
	      	multiple: false,
	    	library : { type : 'application/pdf'},
	    });

	    // highlight selected image
	    file_portfolio_images.on('open', function(){
	    	var selection = file_portfolio_images.state().get('selection');

	    	var attachement = wp.media.attachment(highlight_image);
	    	//attachement.fetch();
	    	selection.add( attachement ? [ attachement ] : [] );
	    });
	 
	    // Finally, open the modal
	    file_portfolio_images.open();	    

		file_portfolio_images.on( 'select', function() {	 
	    	var selection = file_portfolio_images.state().get('selection');
	 
	    	selection.map( function( attachment ) {	 
	      		attachment = attachment.toJSON();
				
				imageArray.push(attachment.id);
				//var img_str = imageArray.toString();
				var result = $.unique(imageArray)
				//alert('result='+ result);
				$(".docs_images_input").val(result);
				$(".docs_images_input").data("id", result);
	 			if($(".docs_image_area .docs_image img").attr('src') == ''){
	 			  $(".docs_image_area .docs_image img").attr("src", attachment.url);
		    	} else { 
		    	  $(".docs_image_area").prepend("<div class='docs_image'><img src='" + attachment.url + "' style='width:140px;margin-top:8px;' ><span id="+attachment.id+" >remove</span></div>");
		    	}  
		    });

		});
});
	
});//close  document
function ucwords (str) {
    return (str + '').replace(/^([a-z])|\s+([a-z])/g, function ($1) {
        return $1.toUpperCase();
    });
}
function validateAlphabet(value) {
	 var regexp = /^[a-zA-Z ]*$/;
	 return regexp.test(value);
}
	
})(jQuery);