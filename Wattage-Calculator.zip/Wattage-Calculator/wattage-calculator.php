<?php 
/* 
Plugin Name:Wattage Calculator
Plugin URI: http://maheragroupbd.com/wootest/
Description: <strong>Auto Quotes and Orders</strong>  This is a very simple leight-weight plugin to get a quotation for auto trasportation and make an order.
Author: Md Mamunur Rahman 
Version: 3.0.0 
Author URI:http://maheragroupbd.com/wootest/
*/ 
//********************************************
//	Constant Paths
//***********************************************************
if( !defined("QUOTATION_HOME") ){
	define("QUOTATION_HOME", plugin_dir_path( __FILE__ ));
}

if( !defined('QUOTATION_DIR') ){
	define( 'QUOTATION_DIR', plugins_url() . '/Wattage-Calculator/' );
}

if( !defined("JS_DIR") ){
	define("JS_DIR", QUOTATION_DIR . "js/");
}

if( !defined("CSS_DIR") ){
	define("CSS_DIR", QUOTATION_DIR . "css/");
} 
remove_filter( 'pre_term_description', 'wp_filter_kses' );
function wattage_calculator_scripts () { 
wp_enqueue_script('jquery-ui-datepicker');
wp_enqueue_style('font-awesome', CSS_DIR . 'font-awesome.css' );
wp_enqueue_style('bootstrap-min', CSS_DIR . 'bootstrap.min.css' );
wp_enqueue_style('listing-css', CSS_DIR . 'listing_style.css' );
wp_enqueue_script('quotation', JS_DIR . 'custom.js', array('jquery'), false, true); 
    // You need styling for the datepicker. For simplicity I've linked to Google's hosted jQuery UI CSS.
    wp_register_style('jquery-ui', 'https://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css');
    wp_enqueue_style('jquery-ui');
    if (!wp_script_is('jquery-ui')) {
        wp_enqueue_script('jquery-ui', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js');
    }  
  wp_localize_script('quotation', 'frontend_ajax_object',
    array( 
        'ajaxurl' => admin_url( 'admin-ajax.php' )
    )
  );
} 
add_action( 'wp_enqueue_scripts', 'wattage_calculator_scripts' ); 
//********************************************
//	Admin Listing Scripts
//***********************************************************
function wattage_calculator_admin_scripts(){
	wp_enqueue_style('jquery-style', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.2/themes/smoothness/jquery-ui.css');
    wp_enqueue_script( 'jquery' );
	wp_enqueue_script('jquery-ui-datepicker');
	wp_enqueue_script('jquery-validate', 'http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js');
	wp_enqueue_media();
	wp_enqueue_style( 'admin_style', CSS_DIR . "admin.css");
	wp_register_script( 'admin-js', JS_DIR . "admin.js", array('jquery'), false, true);
	wp_localize_script( 'admin-js', 'ajax_object', array(
		'ajaxurl' => admin_url( 'admin-ajax.php'),
		'title' => 'Upload an Image',
        'button' => 'Use this Image',
	));	
	wp_enqueue_script( 'admin-js' );
}
add_action( 'admin_enqueue_scripts', 'wattage_calculator_admin_scripts' );

  require_once 'functions/functions.php';
  require_once 'include/taxonomy-image.php';
  require_once 'include/admin-interface.php';
  require_once 'shortcodes/shortcodes.php';
?>