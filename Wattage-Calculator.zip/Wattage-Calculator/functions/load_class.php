<?php
class load_data{
public $make_models = array();
function __construct() {
  global $wpdb;
$make_models_result = $wpdb->get_results("SELECT
    tt.*,
    t.`name` AS term_name
FROM `wpse_term_taxonomy` tt
LEFT JOIN wpse_terms t ON tt.`term_id` = t.`term_id`
WHERE taxonomy = 'make_models'");
//echo '<pre>';
//print_r($make_models_result);

 foreach ($make_models_result as $make_models_row) {
    // create a child element in parent
    if ($make_models_row->parent > 0 && !isset($make_models[$make_models_row->parent])) {
        $make_models[$make_models_row->parent]['models'] = array();
    }

    // makes
    if ($make_models_row->parent > 0) {
        $make_models[$make_models_row->parent]['models'][] = array(
            'term_taxonomy_id' => strip_tags($make_models_row->term_taxonomy_id),
            'term_id' => strip_tags($make_models_row->term_id),
            'term_name' => strip_tags($make_models_row->term_name)
        );
    }
 }//for

	//add_action('login_enqueue_scripts', array( $this,'my_admin_head'));
} // function close
} // class close
